# Plugin Development for RTCamp

Full list of sections and features which i will build during this assignment.

* Modular Administrator Area
* Custom Post Type Manager
* Custom Taxonomy Manager
* Widget to Upload and Diplay media in sidebar
* Post and Pages Gallery integration
* Testimonial section: Comment in the front-end, Admins can approve comments, section which comments to display
* Custom template sections
* Ajax based Login/Registration system
* Membership protected area
* Chat system